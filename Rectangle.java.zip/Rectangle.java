public class Rectangle {
	private double width = 1;
	private double height = 1;

	public Rectangle() {
	}

	public Rectangle(double width, double height) {
		this.width = width;
		this.height = height;
	}

	public double getArea() {
		return width * height;
	}

	public double getPerimeter() {
		return 2 * (width + height);
	}

	public double getWidth() {
		return width;
	}

	public double getHeight() {
		return height;
	}

	public static void main(String[] args) {
		Rectangle rectangle1 = new Rectangle(4, 40);
		Rectangle rectangle2 = new Rectangle(3.5, 35.9);

		System.out.println("Rectangle 1: ");
		System.out.println("Width: " + rectangle1.getWidth());
		System.out.println("Height: " + rectangle1.getHeight());
		System.out.println("Area: " + rectangle1.getArea());
		System.out.println("Perimeter: " + rectangle1.getPerimeter());

		System.out.println();

		System.out.println("Rectangle 2: ");
		System.out.println("Width: " + rectangle2.getWidth());
		System.out.println("Height: " + rectangle2.getHeight());
		System.out.println("Area: " + rectangle2.getArea());
		System.out.println("Perimeter: " + rectangle2.getPerimeter());
	}
}
